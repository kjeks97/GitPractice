package com.cp.admin.notice.service;

public interface NoticeService {

}
