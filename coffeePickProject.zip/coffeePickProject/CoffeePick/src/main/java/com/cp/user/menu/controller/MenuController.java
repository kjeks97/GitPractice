package com.cp.user.menu.controller;

public class MenuController {

}
