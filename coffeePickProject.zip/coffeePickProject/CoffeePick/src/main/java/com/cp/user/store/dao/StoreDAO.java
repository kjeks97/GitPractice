package com.cp.user.store.dao;

public class StoreDAO {

}
