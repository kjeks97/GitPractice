package com.cp.user.menu.service;

public class MenuServiceImpl {

}
