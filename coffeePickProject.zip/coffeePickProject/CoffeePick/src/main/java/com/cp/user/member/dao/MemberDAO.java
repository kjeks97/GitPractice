package com.cp.user.member.dao;

public class MemberDAO {

}
