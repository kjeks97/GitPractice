package com.cp.user.pickmoney.vo;

public class PickmoneyVO {

}
