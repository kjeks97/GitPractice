package com.cp.user.member.service;

public interface MemberService {

}
