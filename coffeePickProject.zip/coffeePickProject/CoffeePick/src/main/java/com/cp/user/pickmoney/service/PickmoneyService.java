package com.cp.user.pickmoney.service;

public interface PickmoneyService {

}
