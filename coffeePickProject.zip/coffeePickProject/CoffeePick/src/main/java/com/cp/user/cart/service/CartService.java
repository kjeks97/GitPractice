package com.cp.user.cart.service;

import java.util.List;

import com.cp.user.cart.vo.CartVO;

public interface CartService {
	public List<CartVO> cartList(CartVO cvo);
}
