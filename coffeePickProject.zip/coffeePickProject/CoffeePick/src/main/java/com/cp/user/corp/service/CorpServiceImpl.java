package com.cp.user.corp.service;

public class CorpServiceImpl {

}
