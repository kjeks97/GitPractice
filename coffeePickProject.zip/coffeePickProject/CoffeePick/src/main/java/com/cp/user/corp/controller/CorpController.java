package com.cp.user.corp.controller;

public class CorpController {

}
