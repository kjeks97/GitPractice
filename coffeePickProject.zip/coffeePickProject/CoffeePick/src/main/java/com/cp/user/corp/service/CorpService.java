package com.cp.user.corp.service;

public interface CorpService {

}
