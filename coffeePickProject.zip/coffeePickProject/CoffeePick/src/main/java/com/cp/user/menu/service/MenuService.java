package com.cp.user.menu.service;

public interface MenuService {

}
