package com.cp.user.corp.dao;

public class CorpDAO {

}
