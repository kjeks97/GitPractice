package com.cp.admin.member.controller;

public class MemberController {

}
