package com.cp.user.cart.dao;

import java.util.List;

import org.apache.ibatis.annotations.Mapper;

import com.cp.user.cart.vo.CartVO;


@Mapper
public interface CartDAO {
	public List<CartVO> cartList(CartVO cvo);
	
}
