package com.cp.user.store.service;

public interface StoreService {

}
