package com.cp.admin.qna.controller;

public class QnaController {

}
