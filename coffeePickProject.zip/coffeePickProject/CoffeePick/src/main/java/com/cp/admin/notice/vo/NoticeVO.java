package com.cp.admin.notice.vo;

public class NoticeVO {

}
