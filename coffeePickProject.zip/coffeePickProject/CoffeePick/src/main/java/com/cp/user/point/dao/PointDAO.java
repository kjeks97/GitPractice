package com.cp.user.point.dao;

public class PointDAO {

}
