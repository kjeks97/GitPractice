package com.cp.admin.event.vo;

public class EventVO {

}
