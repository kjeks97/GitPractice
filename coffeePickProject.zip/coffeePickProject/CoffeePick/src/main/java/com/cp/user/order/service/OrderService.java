package com.cp.user.order.service;

public interface OrderService {

}
