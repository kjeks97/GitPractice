package com.cp.admin.event.dao;

public class EventDAO {

}
