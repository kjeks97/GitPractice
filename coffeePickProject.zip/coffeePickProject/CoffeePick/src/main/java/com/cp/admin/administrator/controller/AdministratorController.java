package com.cp.admin.administrator.controller;

public class AdministratorController {

}
