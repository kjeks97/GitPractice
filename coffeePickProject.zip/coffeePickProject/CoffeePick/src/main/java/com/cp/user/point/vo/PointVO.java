package com.cp.user.point.vo;

public class PointVO {

}
