package com.cp.user.corp.vo;

public class CorpVO {

}
