package com.cp.user.qna.controller;

public class QnaController {

}
