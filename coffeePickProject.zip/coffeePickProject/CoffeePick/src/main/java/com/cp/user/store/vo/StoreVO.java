package com.cp.user.store.vo;

public class StoreVO {

}
