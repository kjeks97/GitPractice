package com.cp.user.menu.dao;

public class MenuDAO {

}
