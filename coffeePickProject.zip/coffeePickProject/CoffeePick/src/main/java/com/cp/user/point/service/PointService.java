package com.cp.user.point.service;

public interface PointService {

}
