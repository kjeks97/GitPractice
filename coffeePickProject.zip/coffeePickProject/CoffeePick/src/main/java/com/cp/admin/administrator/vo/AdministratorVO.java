package com.cp.admin.administrator.vo;

public class AdministratorVO {

}
