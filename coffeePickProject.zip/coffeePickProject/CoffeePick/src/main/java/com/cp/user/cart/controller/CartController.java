package com.cp.user.cart.controller;

import java.util.List;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Controller;
import org.springframework.ui.Model;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.ModelAttribute;
import org.springframework.web.bind.annotation.RequestMapping;

import com.cp.user.cart.service.CartService;
import com.cp.user.cart.vo.CartVO;

import lombok.Setter;
import lombok.extern.slf4j.Slf4j;

@Controller
@RequestMapping("/cart/*")
@Slf4j
public class CartController {
	@Setter(onMethod_ = @Autowired)
	private CartService cartService;

	/********************************************
	 * 장바구니 구현
	 * 
	 *******************************************/
	@GetMapping("/list")
	public String cartList(@ModelAttribute CartVO cvo, Model model) {
		log.info("cart 호출 성공");

		cvo.setCart_id("cart1");
		// 전체레코드조회
		List<CartVO> cartList = cartService.cartList(cvo);
		model.addAttribute("cartList", cartList);
		
		
		return "memberService/cart";
	}

}
