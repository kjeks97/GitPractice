package com.cp.user.cart.vo;

import lombok.Data;



@Data
public class CartVO {
	private String cart_id;
	private String member_id;
	private int cart_detail_no;
	private int cart_detail_menu_quantity;
	private int menu_no;
}
