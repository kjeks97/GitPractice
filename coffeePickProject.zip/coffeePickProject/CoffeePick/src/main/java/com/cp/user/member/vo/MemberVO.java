package com.cp.user.member.vo;

public class MemberVO {

}
