package com.cp.user.cart.dao;

import java.util.List;

import org.junit.jupiter.api.Test;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.boot.test.context.SpringBootTest;

import com.cp.user.cart.vo.CartVO;


import lombok.Setter;
import lombok.extern.slf4j.Slf4j;

@Slf4j
@SpringBootTest
public class CartTests {
	@Setter(onMethod_ = @Autowired)
	private CartDAO cartDAO;
	
	@Test
	public void CartListTest() {
		log.info("-----------");
		
		
		CartVO cvo = new CartVO();
		
		cvo.setCart_id("cart1");
		
		List<CartVO> list = cartDAO.cartList(cvo);
		
		
		if (list != null) {
		    for (CartVO vo : list) {
		        if (vo != null) {
		            log.info(vo.toString());
		        }
		    }
		} else {
		    log.info("List is null.");
		}
	}
	
	
}
